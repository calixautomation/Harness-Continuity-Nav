# TLC Carrier Board - Build & Design Documentation (Rev N)

RPi-driven 64-channel LED carrier: 4x TLC5925 constant-current sink drivers,
integrated power distribution for two plug-in buck modules, USB-C power output
to the Pi, and mechanical rails carrying the Pi itself.

## Board overview
- 88 x 119 mm main board, 2-layer FR-4 1.6mm, 1oz copper (order 2oz outer for 5A headroom)
- Left side: rail at top (RPi upper mount) + solid power panel (RPi lower mount,
  VIN distribution, buck module bay, perfboard-optional holes)
- Right side: RPi ribbon (J1), 4x TLC5925 + decoupling, 64-ch output header (J2),
  limit switch / buzzer headers, test points

## Power architecture
```
12V DC -> T3 -> /VIN pour -> T4 ----buck1 (5V,5A)---- T1 -> /5V_USB_IN -> F1(5A) -> /5V_USB
                          -> T5 ----buck2 (5V,5A)---- T2 -> /5V_B2 (LED + LCD power)
/5V_USB -> USB-C VBUS (J5, SOURCE mode, Rp=10k advertises 5V/3A) -> C-to-C cable -> Pi
/5V_USB -> J1 ribbon 5V pins (parallel path to Pi via GPIO header)
Pi 3V3 (via ribbon) -> /3V3 trunk -> TLC5925 VDD + limit switch headers
```
- The polyfuse F1 protects EVERYTHING downstream of buck1: the Pi (both paths) and board logic.
- Buck modules are NOT soldered: each bridges two screw terminals on ~15mm 18AWG
  solid-core stubs (VIN pins into T4/T5, VOUT pins into T1/T2). Swap = 4 screws.
- VIN range 6.5-17V (TPS565201 needs headroom above 5V). 12V/4A adapter recommended.
- USB-C is an always-on source: VBUS is live whenever the bucks are powered.

## LED current (R1-R4, one R-EXT per chip)
I_OUT = (1.21V / R_EXT) x 18 per channel.
- Red LEDs (Vf~2.0V): use 2.2k -> 10mA (1k/20mA overheats the TSSOP with all 16 ch on)
- Blue LEDs (Vf~3.2V): use 1.5k -> 15mA (or 1k/20mA, chip runs warm)
- Chips can use different values per bank. 1% tolerance.
- For experimenting: tack axial THT resistors onto the 0805 pads.

## Peripheral headers
- J11/J12 limit switches: 3V3 / GND / Signal (1k series to GPIO23/24).
  Mechanical switch: wire S-to-G, enable Pi internal pull-up. 3V3 supply means
  even powered sensors cannot overdrive the GPIO.
- J13 buzzer: Signal(GPIO18) / 5V / GND - for 5V buzzer modules.
- J9 LCD power: Molex PicoBlade 1.25mm, 5V_B2 + GND.
- J10 LED power out: screw terminal on 5V_B2.

## Mechanical
- RPi mounts vertically on the left: M2.5 holes at exact 58x49mm pattern
  (H5/H6 on the top rail, H7/H8 on the panel). **Use 15mm standoffs** - the
  terminal row sits under the Pi.
- Buck modules lie in the panel bay between T4/T5 and T1/T2 (~23mm bridge).
  Optional: zip-tie through H9 for extra retention.
- 3 fiducials included for machine assembly; ignore for hand build.

## Fabrication
Any standard fab (PCB Power / LionCircuits in India, JLCPCB): 2 layers, 1.6mm,
min track/space used 0.25mm, min via 0.6/0.3mm, copper-to-edge >=0.3mm.
Recommend 2oz outer copper (T1 lane carries Pi current; 2oz doubles margin).

## Bring-up checklist
1. Refill zones (B) and run DRC after any edit. Update PCB from Schematic with
   "delete footprints with no symbol" UNCHECKED (T3-T5 + /VIN are PCB-only;
   TP6 exists in schematic only - add symbols / remove TP6 to fully sync).
2. Populate F1 before first power. Verify buck outputs = 5.0V unloaded BEFORE
   bridging into T1/T2.
3. First power without Pi: check 5V on TP7 (5V-PI) and TP8 (5V-LED), 0V ripple sanity.
4. Connect Pi via USB-C only, boot, then attach ribbon.
5. LED test: shift 0xFFFF..., latch, watch current draw (~1.3A max at 20mA x 64).

## Known schematic/PCB sync gaps (deliberate)
- T3, T4, T5 and net /VIN exist only in the PCB.
- TP6 exists only in the schematic.
- Add symbols in Eeschema when convenient; until then keep footprint-deletion
  unchecked during netlist updates.
