Place the downloaded STEP here as RaspberryPi4B.step
