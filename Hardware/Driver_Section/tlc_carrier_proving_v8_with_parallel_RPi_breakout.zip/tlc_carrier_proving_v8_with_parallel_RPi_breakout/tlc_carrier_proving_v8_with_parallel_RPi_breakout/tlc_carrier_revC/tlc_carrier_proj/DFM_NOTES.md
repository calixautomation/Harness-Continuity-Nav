# DFM & Revision Notes — tlc_carrier

## Changes made in this revision

**Functional fix (important):**
- **R6/R7 (USB-C CC resistors) rewired.** They were 10k pull-ups from CC1/CC2 to 5V (source configuration). This board is a power *sink*, so they are now 5.1k pull-downs to GND (pad 2 re-netted to GND, stub + via to the B.Cu ground plane added at x=75.2). Without this, a C-to-C cable from any compliant USB-C charger would never enable VBUS. Populate R6/R7 with **5.1kΩ**.

**DFM fixes:**
1. Silkscreen references bumped from 0.8mm/0.12mm stroke to 0.9mm/0.15mm — meets typical fab minimum legend width (≥0.153mm) so text stays legible.
2. GND plane pulled back 0.3mm from the board edge (was flush at the outline) — prevents exposed copper at routed edges.
3. Three fiducials added (FID1–FID3, 1mm pad / 2mm mask opening) at board corners for automated pick-and-place alignment. Excluded from BOM and position files.
4. Board-level constraints written into the project file: min clearance 0.15mm, min track 0.15mm, min via 0.5/0.3mm, copper-to-edge 0.3mm, annular ring 0.13mm, mask sliver 0.1mm. These match JLCPCB/PCBPower/LionCircuits standard 2-layer capability with margin — nothing on the board pushes fab limits.
5. Footprint fields added to all 40 schematic symbols, so "Update PCB from Schematic" and BOM export are now consistent (previously footprints existed only in the PCB).

## Fab specs to order (any standard fab: JLCPCB, PCBWay, PCB Power (India), LionCircuits (India))
- 2-layer FR-4, 1.6mm, 1oz copper, HASL or ENIG
- Min track/space used: 0.25mm / 0.25mm (well above 0.15mm capability)
- Min drill: 0.3mm vias, standard
- Board size: 96 × 119 mm

## Sourcing (Delhi / India)
- **TLC5925:** Robu.in stocks **TLC5925IDWR (SOIC-24)**; the board uses **TSSOP-24 (TLC5925IPWR)** — order the PW part from Element14 India or Mouser India (both price duty-inclusive and deliver to Delhi in ~3–7 days). If you'd rather use the Robu SOIC part, the four footprints must be swapped and the driver section re-routed — say the word and I'll do that revision.
- **Passives (0805 R/C), headers, terminal blocks, electrolytics:** Bhagirath Palace / Lajpat Rai Market in person, or Robu.in / Evelta online.
- **2×32 IDC header (J2):** uncommon size locally — verify before committing, or consider splitting into two 2×16 headers.
- **USB-C (J5):** GCT USB4105-GF-A via Evelta/Element14; generic 16-pin power-only USB-C receptacles with the same footprint are also common.

## Assembly notes
- TSSOP-24 (0.65mm pitch) is comfortably hand-solderable with flux + drag soldering, or use a stencil + hotplate.
- Populate F1 (polyfuse) before first USB power-up.
- Verify LED current: Rext = 1k → ~22mA per channel per TLC5925 datasheet curve. Adjust R1–R4 if your LEDs need different current.


## Rev B — mechanical & placement changes (this revision)
- **Board outline**: three 12mm rectangular rails extend 60mm off the left edge (x=2..62):
  - Rails 1 & 2 (y 18-30, y 76-88): Raspberry Pi mount, vertical orientation. Holes H5-H8 are 2.7mm (M2.5) at the exact RPi pattern: 49mm x 58mm.
  - Rail 3 (y 108-120): perfboard rail with three 3.2mm (M3) holes H9-H11 at 22mm spacing — the buck converters on perfboard mount here, directly below the Pi.
- **USB-C (J5)** moved to the top-left corner (65.5,10), receptacle overhanging the left edge above the Pi rails. CC pulldowns R6/R7 and their GND vias moved with it.
- **T1/T2 (5V from bucks)** moved to the bottom edge (65,115 / 76,115), each landing inside its own extended copper pour foot — short wire runs up from the perfboard bucks below.
- **Zones reshaped**: 5V_USB is now an L (top-left block + 2.8mm lane down the left edge + bottom foot for T1). 5V_B2 shifted right (x>=66) and extended down with a foot for T2. **Refill zones in KiCad (hotkey B) after opening.**
- H1 -> (65,28), H3 -> (88,117), fiducials repositioned clear of mounting holes.
- Silkscreen: U1-U4 and J5 outlines shrunk off pads, J1/J2 refs moved off outlines, bottom GPIO labels restaggered, stray duplicate text removed.

## Your local DRC (report dated 2026-07-14)
- 38 annular-width errors: your copy has 0.5mm vias (0.10mm ring < 0.13 min). One-click fix: Edit > Edit Track & Via Properties > vias -> 0.6mm. This delivered file already uses 0.6mm.
- lib_footprint_issues / mismatch warnings: cosmetic — the board embeds its own footprints; your local libraries differ or are absent ('carrier', 'Fuse_SMD'). Safe to ignore or right-click > Exclude.
- silk_overlap / silk_over_copper: all fixed in this file.

## Rev C — fuse-bypass fix + perfboard rail resize
**Real bug fixed: USB-C fuse was bypassed.** The schematic runs J5 -> /5V_USB_IN -> F1 -> /5V_USB, but the PCB had J5's VBUS pads netted directly to the post-fuse /5V_USB pour (F1 input floating). This is exactly what your hand-drawn track was trying to fix — and why you got shorting_items/solder_mask_bridge errors: that track clipped the shield pad and CC2. Rev C does it properly:
- J5 pads 1/2 re-netted to /5V_USB_IN
- Clean route: 0.35mm necks out of the fine-pitch pad column (neighbors are 0.65mm away, so a fat exit can't fit), widening to 0.8mm, running up over R6/R7 at y=6.2, down the x=76.6 corridor, across at y=17.0 into F1 pad 1. Verified >=0.15mm to shield pads, R6/R7, CC vias and C6.
- **Delete your hand-drawn /5V_USB_IN tracks** near J5 and refill zones; this file's routing replaces them.
- 3 stranded GND stitching vias (65.785,53.4 / 65.785,59.8 / 66.485,89.7) deleted — they fell into the gap between the reshaped 5V zones and would dangle.

**Perfboard rail:** now five M3 holes at 12mm pitch (x = 6,18,30,42,54 at y=114). Rails are 12mm wide x 60mm long. Mount your 100x70 perfboard with its 70mm edge along the rail (drill the perfboard to match any 2-3 of the five holes); the board hangs downward on standoffs with both SmartElex TPS565201 modules on it. Note: 10x7x3cm on the Robu listing is the shipping box - the actual module PCB is only ~25x20mm, so two of them fit with lots of room.

**Middle rail has 2 holes by design** - the two RPi rails carry exactly the Pi's 4-hole pattern (58 x 49mm), two holes per rail.

## Your DRC rev-2 report - remaining items are in YOUR working copy, not this file:
- 38x annular_width: your copy still has 0.5mm vias. Fix once: select all vias (Edit > Edit Track & Via Properties) -> via size 0.6mm.
- shorting_items / solder_mask_bridge (4+6): your manual /5V_USB_IN tracks - delete them, use this file's routing.
- via_dangling (2): the stranded vias listed above - deleted here.
- unconnected zone-zone: a B.Cu GND island near the top-left corner; enable "Remove islands" in the GND zone properties and refill (B).
- lib_footprint warnings (54): cosmetic, ignore.


## Rev F - USB-C reconfigured as POWER SOURCE
Topology: buck -> T1 -> /5V_USB_IN pour -> VBUS pads -> C-to-C cable -> Pi's own USB-C power input. F1 taps the same pre-fuse node to feed the board's /5V_USB rail (C6, TP7, J1 ribbon 5V).
- R6/R7 flipped from 5.1k Rd (to GND) to **10k Rp pulled up to /5V_USB_IN** - advertises 5V/3A to the sink (Pi). GND stubs and vias at (75.2, 8.25/11.75) removed; pad2s tied into the 5V_USB_IN corridor with one vertical segment at x=73.95.
- **Update your schematic to match** (R6/R7: 10k, CCx to 5V_USB_IN) or the next "Update PCB from Schematic" will revert the pads to GND.
- Compliance note: VBUS here is always-on (no source controller doing Rd-detect before enabling). Ubiquitous on hobby boards and fine for powering a Pi, but anything plugged into this port gets live 5V immediately - label the port.
- Backfeed note: if the J1 ribbon's 5V pins are connected, the Pi receives 5V via BOTH its USB-C jack and the GPIO header (through F1). Same source, so it works, but current sharing is uneven (fuse resistance in one path). If you want a single clean path, lift the 5V pins from the ribbon or keep F1 as the only board-rail tap and don't route ribbon 5V to the Pi.
